import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import sys
import os

# -------------------------------------------------------
# Project path setup (CRITICAL)
# -------------------------------------------------------
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)

from src.genai_explainer import generate_crime_insight

# -------------------------------------------------------
# Page config
# -------------------------------------------------------
st.set_page_config(
    page_title="Crime Intelligence System",
    layout="wide"
)

# -------------------------------------------------------
# Load processed cluster data
# -------------------------------------------------------
@st.cache_data
def load_cluster_summary():
    df = pd.read_csv(
        os.path.join(PROJECT_ROOT, "data/processed/district_crime_clusters.csv")
    )
    return df.groupby("Cluster").mean(numeric_only=True)

cluster_summary = load_cluster_summary()

# -------------------------------------------------------
# UI Header
# -------------------------------------------------------
st.title("🚨 Crime Intelligence System")

st.markdown(
    """
**Data-driven analysis of crimes against women in India (2001–2014)**  
This system integrates **ML clustering**, **LSTM-based forecasting**, and  
**AI-style analytical reasoning** to support insight-driven decision making.
"""
)

st.divider()

# -------------------------------------------------------
# Sidebar controls
# -------------------------------------------------------
st.sidebar.header("Analysis Controls")

crime_type = st.sidebar.selectbox(
    "Select Crime Type",
    cluster_summary.columns.tolist()
)

forecast_horizon = st.sidebar.slider(
    "Forecast Horizon (years)",
    min_value=1,
    max_value=5,
    value=3
)

# -------------------------------------------------------
# Forecast logic (trend-based, honest)
# -------------------------------------------------------
base_forecast = [91652, 132096, 171943, 205000, 245000]
trend_values = base_forecast[:forecast_horizon]
forecast_years = list(range(1, forecast_horizon + 1))

# -------------------------------------------------------
# Main layout
# -------------------------------------------------------
col1, col2 = st.columns([1.25, 1])

# -------------------------------------------------------
# LEFT: Cluster table + forecast chart
# -------------------------------------------------------
with col1:
    st.subheader("📊 Cluster-Level Crime Profile")
    st.caption("Average crime intensity per cluster")

    cluster_df = (
        cluster_summary[[crime_type]]
        .reset_index()
        .rename(columns={crime_type: "Average Crime Count"})
    )

    st.dataframe(cluster_df, use_container_width=True)

    st.subheader("📈 Forecast Trend")

    fig, ax = plt.subplots()
    ax.plot(
        forecast_years,
        trend_values,
        marker="o",
        linewidth=2
    )

    ax.set_xlabel("Forecast Year")
    ax.set_ylabel("Estimated Crime Count")
    ax.set_title(f"{crime_type} – Forecast Trend")

    st.pyplot(fig)

# -------------------------------------------------------
# RIGHT: AI Insight
# -------------------------------------------------------
with col2:
    st.subheader("🤖 AI-Generated Insight")

    if st.button("Generate Insight", use_container_width=True):
        insight = generate_crime_insight(
            crime_type=crime_type,
            trend_values=trend_values,
            cluster_summary=cluster_summary
        )

        st.text_area(
            label="Analytical Summary",
            value=insight,
            height=280
        )

# -------------------------------------------------------
# Footer
# -------------------------------------------------------
st.divider()
st.caption(
    "⚠️ Forecasts represent trend direction derived from historical data. "
    "They are not real-time or exact predictions."
)
