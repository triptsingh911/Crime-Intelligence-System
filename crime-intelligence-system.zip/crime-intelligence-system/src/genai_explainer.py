def generate_crime_insight(crime_type, trend_values, cluster_summary):
    start = trend_values[0]
    end = trend_values[-1]
    horizon = len(trend_values)

    growth_pct = ((end - start) / start) * 100 if start != 0 else 0

    if horizon <= 2:
        horizon_text = "short-term"
    elif horizon <= 4:
        horizon_text = "medium-term"
    else:
        horizon_text = "long-term"

    if growth_pct < 10:
        severity = "mild increase"
    elif growth_pct < 30:
        severity = "moderate increase"
    else:
        severity = "sharp increase"

    high_risk_cluster = cluster_summary.sum(axis=1).idxmax()

    insight = f"""
Crime Analysis Summary for {crime_type}

• Forecast Horizon: {horizon}-year ({horizon_text})
• Trend shows a {severity} (~{growth_pct:.1f}% growth).
• Highest concentration of related crimes appears in Cluster {high_risk_cluster}.
• Longer forecast horizons indicate compounding structural risk rather than short-term fluctuation.
• Policy focus should prioritize districts in this cluster for preventive intervention.
"""
    return insight.strip()
