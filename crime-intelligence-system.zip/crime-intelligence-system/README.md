# 📊 Crime Intelligence System (Crimes Against Women – India)

## Overview
This project is an **end-to-end Crime Intelligence System** that analyzes long-term patterns in crimes against women in India using **Machine Learning, Deep Learning, and Generative AI-style reasoning**.

The system goes beyond basic visualization by:
- Discovering **district-level crime behavior patterns**
- Forecasting **future crime trends**
- Generating **human-readable analytical insights**
- Running fully **offline** with **no paid APIs**

---

## Problem Statement
Public crime data in India is **fragmented, coarse-grained, and historical**.  
Most analyses stop at charts and counts.

**Objective:**  
Build a decision-support system that:
- Identifies structural crime patterns  
- Groups districts by crime behavior (not geography)  
- Predicts future trends  
- Explains results in natural language  

---

## Dataset
**Source:** NCRB-style public dataset  
**Coverage:** Crimes Against Women (2001–2014)

**Features include:**
- State / District
- Year
- Crime categories:
  - Rape
  - Kidnapping & Abduction
  - Dowry Deaths
  - Assault on women
  - Cruelty by husband or relatives
  - Insult to modesty
  - Importation of girls

No missing values. Fully numeric crime counts.

---

## System Architecture
```
Raw Crime Data (CSV)
        ↓
Data Cleaning & Reshaping (Wide → Long)
        ↓
ML Clustering (District Crime Profiles)
        ↓
DL Forecasting (LSTM Time Series)
        ↓
GenAI Reasoning Layer
        ↓
Interactive Streamlit Dashboard
```

---

## Key Components

### 1️⃣ Feature Engineering
- Converted wide-format crime data into **tidy long format**
- Enabled cross-crime and temporal analysis
- Created reusable processed datasets

### 2️⃣ Machine Learning – Crime Pattern Discovery
- Aggregated district-level crime vectors
- Applied **KMeans clustering**
- Identified **5 distinct district crime profiles**

### 3️⃣ Deep Learning – Crime Trend Forecasting
- Built **LSTM-based time-series model**
- Forecasted future national crime trends per category
- Focused on trend direction, not exact prediction

### 4️⃣ GenAI Reasoning Engine
- Synthesizes ML cluster outputs and DL forecasts
- Produces human-readable analytical insights
- Fully offline (no paid APIs)

### 5️⃣ Streamlit Dashboard
- Interactive crime-type selection
- On-demand AI-generated insights
- Designed for non-technical users

---

## Tech Stack
- Python
- Pandas, NumPy
- Scikit-learn
- TensorFlow / Keras
- Streamlit
- Matplotlib, Seaborn

---

## How to Run
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
streamlit run app/streamlit_app.py
```

---

## Limitations
- Yearly data only (no real-time prediction)
- District-level granularity
- Trend forecasting, not exact crime counts

---

## Future Improvements
- Integrate additional NCRB datasets
- Add local Hugging Face LLM
- Advanced anomaly detection
- Finer-grained geo-visualizations

---

## Author
Built as a data science portfolio project demonstrating applied ML, DL, and AI reasoning on real-world public data.
